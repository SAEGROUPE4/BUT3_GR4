### Construction et démarrage de l' application

Démarrer l'application en exécutant  :
`docker compose up --build`.

L'application sera disponible à l'adresse http://localhost:8080/projet.

